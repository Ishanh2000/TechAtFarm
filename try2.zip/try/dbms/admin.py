from django.contrib import admin
from .models import Data, Land, Blog

admin.site.register(Data)
admin.site.register(Land)
admin.site.register(Blog)
# Register your models here.
