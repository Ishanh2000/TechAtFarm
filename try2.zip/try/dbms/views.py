from django.shortcuts import render
from django.http import HttpResponse, Http404, HttpResponseRedirect
from .models import Data, Land, Blog

loggedin_farmer = {}


def index(request):
    return render(request, 'dbms/index.html', {'blogs': Blog.objects.all()})


def signup(request):
    return render(request, 'dbms/signup.html')


def login(request):
    if request.method == 'POST':
        data = request.POST.dict()
        user_name = data.get("user_name")
        password = data.get("password")
        try:
            farmer = Data.objects.get(pk=user_name)
        except Data.DoesNotExist:
            return render(request, 'dbms/login.html', {'username_status': 'Username DOES NOT EXIST!', 'username': user_name})
            #raise Http404("Incorrect  User Name")
        if(farmer.password == password):
            global loggedin_farmer
            loggedin_farmer = farmer
            return HttpResponseRedirect('/dbms/dashboard/')
            # return dashboard(request, farmer)
            # return render(request, 'dbms/dashboard.html', {'farmer': farmer})
        else:
            return render(request, 'dbms/login.html', {'pwd_status': 'INCORRECT PASSWORD!', 'username': user_name})
    else:
        return render(request, 'dbms/login.html')

def logout(request):
    if request.method == 'POST':
        global loggedin_farmer
        loggedin_farmer = {}
        return HttpResponseRedirect('/dbms/login/')

def submit(request):
    if request.method == 'POST':
        data = request.POST.dict()
        username = data.get("user_name")
        try:
            farmer = Data.objects.get(pk = username)
        except Data.DoesNotExist:
            if(data.get('password') != data.get('confirm_password')):
                return render(request, 'dbms/signup.html',{'pwd_status': 'PASSWORDS DO NOT MATCH', 'data': data})
            
            farmer = Data(
            name=data.get('name'),
            mobile_number=data.get('mobile_number'),
            residence=data.get('residence'),
            aadhar=data.get('aadhar'),
            user_name=data.get('user_name'),
            password=data.get('password'),
            )
            farmer.save()
            # return HttpResponse("%s Thanks for Registering with us !" % Name)
            return render(request, 'dbms/signupSuccess.html', {'data': data, })

        else:
            return render(request, 'dbms/signup.html',{'username_status': 'USERNAME ALREADY EXISTS ! TRY SOMETHING ELSE...', 'data': data})



def dashboard(request):
    global loggedin_farmer
    username = loggedin_farmer.user_name
    return render(request, 'dbms/dashboard.html', {'farmer': loggedin_farmer, 'lands': Land.objects.filter(user_name=username)})


def add_land(request):
    if request.method == 'POST':
        data = request.POST.dict()
        global loggedin_farmer
        user_name = loggedin_farmer.user_name
        for land in Land.objects.filter(user_name=user_name):
            if land.land_address.lower() == data.get('land_address').lower():
                if land.land_name.lower() == data.get('land_name').lower():
                    return HttpResponseRedirect('/dbms/dashboard/')
        land_data = Land(
            user_name=loggedin_farmer,
            land_name=data.get('land_name'),
            land_address=data.get('land_address'),
            soil_type=data.get('soil_type'),
            crop_grown=data.get('crop_grown'),
            moisture_requirement=data.get('moisture_requirement'),
        )
        land_data.save()
        return HttpResponseRedirect('/dbms/dashboard/')
