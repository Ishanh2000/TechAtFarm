from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('submit/', views.submit, name = 'submit'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/newLocation', views.add_land, name='add_land'),
    path('dashboard/logout', views.logout, name = 'logout'),
]