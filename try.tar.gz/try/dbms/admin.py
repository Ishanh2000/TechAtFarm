from django.contrib import admin
from .models import Data, Land

admin.site.register(Data)
admin.site.register(Land)
# Register your models here.
