from django.apps import AppConfig


class DbmsConfig(AppConfig):
    name = 'dbms'
