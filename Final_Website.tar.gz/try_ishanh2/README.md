# try_ishanh2
(AUM) Deployment on EC2 AWS
